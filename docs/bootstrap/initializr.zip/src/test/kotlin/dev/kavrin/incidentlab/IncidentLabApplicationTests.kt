package dev.kavrin.incidentlab

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class IncidentLabApplicationTests {

	@Test
	fun contextLoads() {
	}

}
